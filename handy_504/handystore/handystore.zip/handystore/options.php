<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 */
function optionsframework_option_name() {
	// Change this to use your theme slug
	return 'handystore-theme';
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 */

function optionsframework_options() {

	// On/Off array
	$on_off_array = array(
		'on' => esc_html__( 'On', 'plumtree' ),
		'off' => esc_html__( 'Off', 'plumtree' ),
	);

	// Background Defaults
	$background_defaults = array(
		'color' => '',
		'image' => '',
		'repeat' => 'repeat',
		'position' => 'top center',
		'attachment' => 'scroll'
	);

	/**
	 * For $settings options see:
	 * http://codex.wordpress.org/Function_Reference/wp_editor
	 *
	 * 'media_buttons' are not supported as there is no post to attach items to
	 * 'textarea_name' is set by the 'id' you choose
	 */

	$wp_editor_settings = array(
		'wpautop' => false,
		'textarea_rows' => 3,
		'tinymce' => array( 'plugins' => 'wordpress,wplink' )
	);

	// If using image radio buttons, define a directory path
	$imagepath =  get_template_directory_uri() . '/theme-options/images/';

	// Layout options
	$layout_options = array(
		'one-col' => $imagepath . 'one-col.png',
		'two-col-left' => $imagepath . 'two-col-left.png',
		'two-col-right' => $imagepath . 'two-col-right.png'
	);

	$options = array();

	/* Global Site Settings */
	$options[] = array(
		'name' => esc_html__( 'Site Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'site'
	);

	$options[] = array(
		'name' => esc_html__( 'Select layout for site', 'plumtree' ),
		'id' => 'site_layout',
		'std' => 'wide',
		'type' => 'radio',
		'options' => array(
			'wide'  => esc_html__('Wide', 'plumtree'),
			'boxed' => esc_html__('Boxed', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Enable "Maintenance Mode" for site?', 'plumtree' ),
		'desc' => esc_html__( 'When is ON use /wp-login.php to login to your site', 'plumtree' ),
		'id' => 'site_maintenance_mode',
		'std' => 'off',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__('Enter the date when "Maintenance Mode" expired', 'plumtree'),
		'desc' => esc_html__('Set date in following format (YYYY-MM-DD). If you leave this field blank, countdown clock won&rsquo;t be shown', 'plumtree'),
		'id' => 'maintenance_countdown',
		'std' => '',
		'placeholder' => 'YYYY-MM-DD',
		'type' => 'text'
	);

	$options[] = array(
		'name' => esc_html__( 'Extra Features', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Enable "Post like system" for site?', 'plumtree' ),
		'desc' => esc_html__( 'Anabling post like functionality on your site + Extra Widgets (Popular Posts, User Likes)', 'plumtree' ),
		'id' => 'site_post_likes',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array,
	);

	$options[] = array(
		'name' => esc_html__( 'Enable "Post share system" for site?', 'plumtree' ),
		'desc' => esc_html__( 'Anabling post share functionality on your site (available for posts, products, attachments)', 'plumtree' ),
		'id' => 'site_post_shares',
		'std' => true,
		'type' => 'checkbox',
		'class' => 'has_hidden_child'
	);

	$multicheck_array = array(
		'facebook' => esc_html__('Share on Facebook', 'plumtree'),
		'twitter' => esc_html__('Share on Twitter', 'plumtree'),
		'pinterest' => esc_html__('Share on Pinterest', 'plumtree'),
		'google' => esc_html__('Share on Google+', 'plumtree'),
		'mail' => esc_html__('Email to a friend', 'plumtree'),
		'linkedin' => esc_html__('Share on LinkedIn', 'plumtree'),
		'vk' => esc_html__('Share on Vkontakte', 'plumtree'),
		'tumblr' => esc_html__('Share on Tumblr', 'plumtree'),
	);

	$multicheck_defaults = array(
		'facebook' => '1',
		'twitter' => '1',
		'pinterest' => '1',
		'google' => '1',
		'mail' => '1',
		'linkedin' => '1',
		'vk' => '1',
		'tumblr' => '1',
	);

	$options[] = array(
		'name' => __( 'Social Networks for Post Share', 'plumtree' ),
		'desc' => __( 'Check all networks you want to appear in share section', 'plumtree' ),
		'id' => 'share_networks',
		'std' => $multicheck_defaults,
		'type' => 'multicheck',
		'class' => 'hidden',
		'options' => $multicheck_array
	);

	$options[] = array(
		'name' => esc_html__( 'Enable "Scroll to Top button" for site?', 'plumtree' ),
		'desc' => esc_html__( 'If "ON" appears in bottom right corner of site', 'plumtree' ),
		'id' => 'totop_button',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	/* Header Options */
	$options[] = array(
		'name' => esc_html__( 'Header Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'header'
	);

	$header_bg_default = get_site_url().'/wp-content/uploads/2015/02/handy_bg_03.jpg';
	$options[] = array(
		'name' => esc_html__( 'Background for header', 'plumtree' ),
		'desc' => esc_html__( 'Add custom background color or image for header section.', 'plumtree' ),
		'id' => 'header_bg',
		'std' => array(
				'color' => '',
				'image' => $header_bg_default,
				'repeat' => 'repeat',
				'position' => 'top left',
				'attachment' => 'fixed'
		),
		'type' => 'background'
	);

	$options[] = array(
		'name' => esc_html__( 'Top Panel Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Enable header&rsquo;s top panel?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use header top panel', 'plumtree' ),
		'id' => 'header_top_panel',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Enter info contents', 'plumtree' ),
		'desc' => esc_html__( 'Info appears at center of headers top panel', 'plumtree' ),
		'id' => 'top_panel_info',
		'std' => '<i class="fa fa-map-marker"></i> 102580 Santa Monica BLVD Los Angeles',
		'type' => 'textarea'
	);

	/* Footer Options */
	$options[] = array(
		'name' => esc_html__( 'Footer Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'footer'
	);

	$options[] = array(
		'name' => esc_html__( 'Background for footer', 'plumtree' ),
		'desc' => esc_html__( 'Add custom background color or image for footer section.', 'plumtree' ),
		'id' => 'footer_bg',
		'std' => array(
				'color' => '#393E45',
				'image' => '',
				'repeat' => 'repeat',
				'position' => 'top center',
				'attachment' => 'scroll'
		),
		'type' => 'background'
	);

	$options[] = array(
		'name' => esc_html__( 'Enter sites copyright', 'plumtree' ),
		'desc' => esc_html__( 'Enter copyright (appears at the bottom of site)', 'plumtree' ),
		'id' => 'site_copyright',
		'std' => '',
		'type' => 'textarea'
	);

	$options[] = array(
		'name' => esc_html__( 'Footer shortcode section Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Footer shortcode section', 'plumtree' ),
		'desc' => esc_html__( 'Check to use shortcode section located above footer', 'plumtree' ),
		'id' => 'footer_shortcode_section',
		'std' => true,
		'class' => 'has_hidden_childs',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => esc_html__( 'Background for footer shortcode section', 'plumtree' ),
		'desc' => esc_html__( 'Add custom background color or image for shortcode section.', 'plumtree' ),
		'id' => 'footer_shortcode_section_bg',
		'class' => 'hidden',
		'std' => array(
				'color' => '',
				'image' => $header_bg_default,
				'repeat' => 'repeat',
				'position' => 'top left',
				'attachment' => 'fixed'
		),
		'type' => 'background'
	);

	$default_footer_shortcode = '[handy_vendors_carousel cols_qty="5" items_number="6" el_title="Our Vendors"]';
	$options[] = array(
		'name' => esc_html__( 'Enter shortcode', 'plumtree' ),
		'id' => 'footer_shortcode_section_shortcode',
		'std' => $default_footer_shortcode,
		'class' => 'hidden',
		'type' => 'editor',
		'settings' => $wp_editor_settings
	);

	/* Page Templates Options */
	$options[] = array(
		'name' => esc_html__( 'Page Templates Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'templates'
	);

	$options[] = array(
		'name' => esc_html__( 'Front Page Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Front Page shortcode section', 'plumtree' ),
		'desc' => esc_html__( 'Check to use shortcode section located under primary navigation menu', 'plumtree' ),
		'id' => 'front_page_shortcode_section',
		'std' => false,
		'class' => 'has_hidden_childs',
		'type' => 'checkbox'
	);

	$options[] = array(
		'name' => esc_html__( 'Background for shortcode section', 'plumtree' ),
		'desc' => esc_html__( 'Add custom background color or image for shortcode section.', 'plumtree' ),
		'id' => 'front_page_shortcode_section_bg',
		'class' => 'hidden',
		'std' => $background_defaults,
		'type' => 'background'
	);

	$options[] = array(
		'name' => esc_html__( 'Enter shortcode', 'plumtree' ),
		'id' => 'front_page_shortcode_section_shortcode',
		'std' => '',
		'class' => 'hidden',
		'type' => 'editor',
		'settings' => $wp_editor_settings
	);

	$options[] = array(
		'name' => esc_html__( 'Enable Front Page special sidebar?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use front page special sidebar located at the bottom of Front Page Template', 'plumtree' ),
		'id' => 'front_page_special_sidebar',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	/* Layout Options */
	$options[] = array(
		'name' => esc_html__( 'Layout Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'layout'
	);

	$options[] = array(
		'name' => esc_html__('Set Front page layout', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the front page', 'plumtree'),
		'id' => "front_layout",
		'std' => "two-col-left",
		'type' => "images",
		'options' => $layout_options
	);

	$options[] = array(
		'name' => esc_html__('Set global layout for Pages', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the Pages of your site', 'plumtree'),
		'id' => "page_layout",
		'std' => "two-col-left",
		'type' => "images",
		'options' => $layout_options
	);

	$options[] = array(
		'name' => esc_html__('Set Blog page layout', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the Blog page', 'plumtree'),
		'id' => "blog_layout",
		'std' => "one-col",
		'type' => "images",
		'options' => $layout_options
	);

	$options[] = array(
		'name' => esc_html__('Set Single post view layout', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the single posts', 'plumtree'),
		'id' => "single_layout",
		'std' => "two-col-right",
		'type' => "images",
		'options' => $layout_options
	);

	$options[] = array(
		'name' => esc_html__('Set Products page (Shop page) layout', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the products page', 'plumtree'),
		'id' => "shop_layout",
		'std' => "two-col-left",
		'type' => "images",
		'options' => $layout_options
	);

	$options[] = array(
		'name' => esc_html__('Set Single Product pages layout', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the single product pages', 'plumtree'),
		'id' => "product_layout",
		'std' => "two-col-right",
		'type' => "images",
		'options' => $layout_options
	);

	$options[] = array(
		'name' => esc_html__('Set Vendor Store pages layout', 'plumtree'),
		'desc' => esc_html__('Specify the location of sidebars about the content on the vendor store pages', 'plumtree'),
		'id' => "vendor_layout",
		'std' => "two-col-right",
		'type' => "images",
		'options' => $layout_options
	);

	/* Blog Options */
	$options[] = array(
		'name' => esc_html__( 'Blog Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'wordpress'
	);

	$options[] = array(
		'name' => esc_html__( 'Blog Layout Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Enable lazyload effects on blog page?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use Lazyload effects on blog page', 'plumtree' ),
		'id' => 'lazyload_on_blog',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Select layout for blog', 'plumtree' ),
		'id' => 'blog_frontend_layout',
		'std' => 'grid',
		'type' => 'radio',
		'class' => 'hidden-radio-control',
		'options' => array(
			'list'  => esc_html__('List', 'plumtree'),
			'grid'  => esc_html__('Grid', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Select number of columns for Blog "grid layout"', 'plumtree' ),
		'id' => 'blog_grid_columns',
		'std' => 'cols-3',
		'type' => 'radio',
		'class' => 'hidden',
		'options' => array(
			'cols-2'  => esc_html__('2 Columns', 'plumtree'),
			'cols-3'  => esc_html__('3 Columns', 'plumtree'),
			'cols-4' => esc_html__('4 Columns', 'plumtree')
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Single Post Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Enable single post Prev/Next navigation output?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use single post navigation', 'plumtree' ),
		'id' => 'post_pagination',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Enable single post breadcrumbs?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use breadcrumbs on Single post view', 'plumtree' ),
		'id' => 'post_breadcrumbs',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Enable single post share buttons output?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use share buttons', 'plumtree' ),
		'id' => 'blog_share_buttons',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Enable single post Related Posts output?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to show related posts', 'plumtree' ),
		'id' => 'post_show_related',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Select pagination type for comments', 'plumtree' ),
		'id' => 'comments_pagination',
		'std' => 'numeric',
		'type' => 'radio',
		'options' => array(
			'newold'  => esc_html__('Newer/Older pagination', 'plumtree'),
			'numeric'  => esc_html__('Numeric pagination', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Enable lazyload effects on single post?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use Lazyload effects on single post', 'plumtree' ),
		'id' => 'lazyload_on_post',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	/* Store Options */
	$options[] = array(
		'name' => esc_html__( 'Store Options', 'plumtree' ),
		'type' => 'heading',
		'icon' => 'basket'
	);

	$options[] = array(
		'name' => esc_html__( 'Enable Catalog Mode?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "ON" if you want to switch your shop into a catalog mode (no prices, no "add to cart")', 'plumtree' ),
		'id' => 'catalog_mode',
		'std' => 'off',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Show number of products in the cart widget?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "ON" if you want to show a a number of products currently in the cart widget', 'plumtree' ),
		'id' => 'cart_count',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Show store Breadcrumbs?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use breadcrumbs on store page', 'plumtree' ),
		'id' => 'store_breadcrumbs',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Add special sidebar for filters on Store page?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use special sidebar on products page', 'plumtree' ),
		'id' => 'filters_sidebar',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Store as Front page?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "On" if you want to display Store page on Front page. Don&rsquo;t forget to specify Products Page as static front page in WordPress "Reading Settings".', 'plumtree' ),
		'id' => 'front_page_shop',
		'std' => 'off',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Add "Lazyload" to products?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use Lazyload effects on products.', 'plumtree' ),
		'id' => 'catalog_lazyload',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Store Layout Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Enter number of products to show on Store page', 'plumtree' ),
		'id' => 'store_per_page',
		'std' => '9',
		'class' => 'mini',
		'type' => 'text'
	);

	$options[] = array(
		'name' => esc_html__( 'Select product quantity per row on Store page', 'plumtree' ),
		'id' => 'store_columns',
		'std' => '3',
		'type' => 'radio',
		'options' => array(
			'3'  => esc_html__('3 Products', 'plumtree'),
			'4'  => esc_html__('4 Products', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Show List/Grid products switcher?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use switcher on products page', 'plumtree' ),
		'id' => 'list_grid_switcher',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Set default view for products (list or grid)', 'plumtree' ),
		'id' => 'default_list_type',
		'std' => 'grid',
		'type' => 'radio',
		'options' => array(
			'grid'  => esc_html__('Grid', 'plumtree'),
			'list'  => esc_html__('List', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Single Product Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Show Single Product pagination (prev/next product)?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use single pagination on product page', 'plumtree' ),
		'id' => 'product_pagination',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Show single product share buttons?', 'plumtree' ),
		'desc' => esc_html__( 'Switch to "Off" if you don&rsquo;t want to use single product share buttons', 'plumtree' ),
		'id' => 'use_pt_shares_for_product',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Show single product up-sells?', 'plumtree' ),
		'id' => 'show_upsells',
		'std' => 'on',
		'type' => 'radio',
		'class' => 'has_hidden_childs_radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Select how many Up-Sell Products to show on Single product page', 'plumtree' ),
		'id' => 'upsells_qty',
		'std' => '2',
		'type' => 'select',
		'class' => 'hidden',
		'options' => array(
			'2'  => esc_html__('2 products', 'plumtree'),
			'3'  => esc_html__('3 products', 'plumtree'),
			'4'  => esc_html__('4 products', 'plumtree'),
			'5'  => esc_html__('5 products', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Show single product related products?', 'plumtree' ),
		'id' => 'show_related_products',
		'std' => 'on',
		'type' => 'radio',
		'class' => 'has_hidden_childs_radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Select how many Related Products to show on Single product page', 'plumtree' ),
		'id' => 'related_products_qty',
		'std' => '3',
		'type' => 'select',
		'class' => 'hidden',
		'options' => array(
			'2'  => esc_html__('2 products', 'plumtree'),
			'3'  => esc_html__('3 products', 'plumtree'),
			'4'  => esc_html__('4 products', 'plumtree'),
			'5'  => esc_html__('5 products', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'WC Vendors Options', 'plumtree' ),
		'type' => 'info'
	);

	$options[] = array(
		'name' => esc_html__( 'Show WC Vendors "Sold by:" in Store page loop products?', 'plumtree' ),
		'id' => 'show_wcv_loop_sold_by',
		'std' => 'on',
		'type' => 'radio',
		'class' => 'has_hidden_childs_radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Special style for "sold by" label', 'plumtree' ),
		'id' => 'wcv_loop_sold_by_style',
		'std' => 'left-slide',
		'type' => 'select',
		'class' => 'hidden',
		'options' => array(
			'left-slide'  => esc_html__('Sliding from left (only icon)', 'plumtree'),
			'bottom-slide'  => esc_html__('Sliding from bottom (only shop name)', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Show single product vendors related products?', 'plumtree' ),
		'id' => 'show_wcv_related_products',
		'std' => 'on',
		'type' => 'radio',
		'class' => 'has_hidden_childs_radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Select how many Vendor Related Products to show on Single product page', 'plumtree' ),
		'id' => 'wcv_qty',
		'std' => '3',
		'type' => 'select',
		'class' => 'hidden',
		'options' => array(
			'2'  => esc_html__('2 products', 'plumtree'),
			'3'  => esc_html__('3 products', 'plumtree'),
			'4'  => esc_html__('4 products', 'plumtree'),
			'5'  => esc_html__('5 products', 'plumtree'),
		)
	);

	$options[] = array(
		'name' => esc_html__( 'Add favourite vendor system?', 'plumtree' ),
		'desc' => esc_html__( 'Special "Add to Favourites" button appears on single vendor shop when "On". So logged in users can add different vendors to their favourite lists & manage them from "My Account" page', 'plumtree' ),
		'id' => 'show_wcv_favourite_vendors',
		'std' => 'off',
		'type' => 'radio',
		'options' => $on_off_array
	);

	$options[] = array(
		'name' => esc_html__( 'Enable simple feedback form for vendors?', 'plumtree' ),
		'desc' => esc_html__( 'Form appears in Seller Info tab on each vendors product', 'plumtree' ),
		'id' => 'enable_vendors_product_feedback',
		'std' => 'on',
		'type' => 'radio',
		'options' => $on_off_array
	);

	return $options;
}
